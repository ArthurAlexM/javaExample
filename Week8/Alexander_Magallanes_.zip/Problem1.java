

import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
  
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter a String: ");
      String userInput = input.nextLine();
      
      
     for (int i = userInput.length() - 1; i > -1; i--){
    
     System.out.print(userInput.charAt(i));
      
  }
   
  
  
}
   }