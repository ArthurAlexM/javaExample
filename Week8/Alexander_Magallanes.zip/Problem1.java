// used to find a character within a string. uses length method and charAt method

import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
  
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter a String: ");
      String str = input.nextLine();
     
     int i = str.length();
   
   System.out.print("Enter a character to look for: ");
      char ch = input.next().charAt(0);
 for (int a = 0; a <= i - 1; a++){    
     if(str.charAt(a) == ch){
      System.out.println(ch + " was found at index " + a);
      break;
     }
    
 if(a == i - 1) System.out.println(ch + " was not found in the string. I love programming.");
      
    
  }
  
  }
   
  
  
}
   