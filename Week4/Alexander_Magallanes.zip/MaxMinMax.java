// Program is used to find the absolute value of 2 intergers and also finding the min and max of those int. then finally raising min to the max power
import java.util.Scanner;
public class MaxMinMax
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter Number 1(must be an interger): ");
   
   
   int n1 = input.nextInt();
   
   
   System.out.print("Enter number 2(must be an interger: ");
   
   
   int n2 = input.nextInt();
   
   int abs = Math.abs(n1);
   
   int abs2 = Math.abs(n2);
   
   if (abs == abs2){
   
   System.out.println("The values are equal");
   }
   else if (abs > abs2){
   System.out.println("The absolute value of " + n1 + " is greater than " + n2);
   int max = Math.max(abs,abs2);
  int min = Math.min(abs,abs2);
  Math.pow(min,max);
  System.out.println("The new max is: " + (int)Math.pow(min,max));
   
   
   }
   
   else if( abs2 > abs){
    System.out.println("The absolute value of " + n2 + " is greater than " + n1);
     int max = Math.max(abs,abs2);
  int min = Math.min(abs,abs2);
  System.out.println("The new max is: " + (int)Math.pow(min,max));
  
  
   }
   }
   }