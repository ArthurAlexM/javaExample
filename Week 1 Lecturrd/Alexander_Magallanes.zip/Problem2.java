public class Problem2
{
   public static void main(String[] args)
   {
  System.out.println("************************************");
  System.out.println("J J J     A     V         V     A");
  System.out.println("  J      A A     V       V     A A");
  System.out.println("  J     A   A     V     V     A   A");
  System.out.println("  J    A A A A     V   V     A A A A");
  System.out.println("J J   A       A     V V     A       A");
  System.out.println(" J   A         A     V     A         A");
  System.out.println("***************************************");
                       
                      
                      
   }
}