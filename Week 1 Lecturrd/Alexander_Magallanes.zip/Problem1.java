public class Problem1
{
   public static void main(String[] args)
   {
   System.out.println("Alexander Magallanes");
   System.out.println("amagallanes2@neiu.edu");
   }
}