import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   int user; 
   do{
   System.out.print("please enter an interger n, greater than 0: ");
   user = input.nextInt();
   } while (!(user > 0));
   if(user > 0){
   int[] nums =  new int[user];
   
   System.out.print("enter " + user + " intergers: ");
      for(int i = 0; i < user; i++){
         nums[i] = input.nextInt();
         }
   System.out.print("You entered: ");
    for(int i = 0; i < user; i++){
      System.out.print(nums[i] + " ");
      }
      
      int max = nums[0];
      for (int i = 1; i < user; i++){
         if (nums[i] > max){
            max = nums[i];
            }
         }
         System.out.println();
         System.out.println();
      System.out.println("Maximum value: " + max);
      
      int min = nums[0];
      
    
   
      for (int i = 1; i < user; i++){
         if (nums[i] < min){
            min = nums[i];
            }
         }
      System.out.println("Minimum value: " + min);
      
      int add = 0;
      for(int i = 0; i < user; i++){
         add += nums[i];   
    }
    double ave = (double)add / user;
    System.out.println("Average: " + ave);
     System.out.println();
         System.out.println();
    System.out.println("Elements greater than average:");     
    for (int i = 0; i < user; i++){
         if (nums[i] > ave){
         
         System.out.print(nums[i] + " ");
            }  
   }
   System.out.println();
   System.out.println("Elements greater than 4:");
   for (int i = 0; i < user; i++){
         if (nums[i] > 4){
         
         System.out.print(nums[i] + " ");
            }  
   }
   System.out.println();
    System.out.println("Array in reverse order: ");
    for(int i = user - 1; i > -1; i--){
      System.out.print(nums[i] + " ");
      }
   
   
   
   
   
   }
 
        
   
  
      
  }
    }
   
   
   
  