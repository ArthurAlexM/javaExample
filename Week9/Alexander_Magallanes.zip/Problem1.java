import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter an interger that is odd and greater or equal to 5: ");
   
    int userInput = input.nextInt();
    
    while (!(userInput >= 5 && userInput % 2 == 1)){
    
     System.out.print("Please enter an interger that is odd and greater or equal to 5: ");
     userInput = input.nextInt();
     }
   
   boxWithMinorDiagonal(userInput);
   
   printNLetter(userInput);
   
   rightTriangle(userInput);
   
   plusInSquare(userInput);
   }
   
   public static void boxWithMinorDiagonal(int n){
      for (int col = 1; col <= n; col++) {
         for (int row = 1; row <= n; row++) {
             if(row == 1 || col == 1 || row == n || col == n){
               System.out.print("*");
              }
             else if (col + row == n+1){
             System.out.print("+");
             }
            else{
            System.out.print(" ");
            }
       
         

      }
       System.out.println();
      }
      
      }   
      
   public static void printNLetter(int n){
   System.out.println();
       for (int col = 1; col <= n; col++) {
         for (int row = 1; row <= n; row++) {
             if(row == 1 || row == n){
               System.out.print("*");
              }
             else if (col == row){
             System.out.print("*");
             }
            else {
               System.out.print(" ");
                  }
   }
   System.out.println();
   }
   
      }
  
  
   public static void rightTriangle(int n){
   System.out.println();
      for (int col = 1; col <= n; col++) {
         for (int row = 1; row <= n; row++) {
             if(col == n || row == 1){
               System.out.print("*");
              }
             else if (col == row){
             System.out.print("*");
             }
            else {
            System.out.print(" ");
               }
       
         

      }
       System.out.println();
      }
      
      } 
  
  
    public static void plusInSquare(int n){
    System.out.println();
      for (int col = 1; col <= n; col++) {
         for (int row = 1; row <= n; row++) {
             if(row == 1 || col == 1 || row == n || col == n){
               System.out.print("*");
              }
             else if (row == n/2 + 1 || col == n/2 + 1){
             System.out.print("+");
             }
           else {
           System.out.print(".");
            }
       
         

      }
       System.out.println();
      }
      
      }
  
  
  
   }
   
  
  
  
