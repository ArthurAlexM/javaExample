import java.io.*;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.util.Arrays;

public class Hangman
{
    
    public static void main(String[] args)
    {
        loadWords(); // loading words

        int num = getRand();
        String[] word = loadWords();
        String secret = word[num];
        Scanner inputs = new Scanner(System.in);

        char[] charArray = stringToChar(secret);




        int a;
        char[] charAnswer;

        a = charArray.length;
        charAnswer = new char[a];


        System.out.println("Welcome to Hangman!");
        System.out.println("I am have a word that is " + a + " letters long");
        for(int i = 0; i <= charArray.length - 1; i++){

            charAnswer[i] = '_';

        }
        System.out.println();


        int guesses = 5;
        boolean check;
        do {
            for (int i = 0; i < charAnswer.length; i++) {
                System.out.print(charAnswer[i]);
                System.out.print(" ");
            }
            System.out.println();

            System.out.println();

            System.out.println("you have " + guesses + " left guesses");
            System.out.print("Enter a letter: ");

            String str = inputs.nextLine();

            char input = str.charAt(0);
            checkAnswer(input, charArray, charAnswer);
            guesses = counter(input, charArray, charAnswer, guesses);
            for(int i = 0; i < charArray.length; i++) {
                if(charAnswer[i] == input){
                    System.out.println("You have already entered that letter");

                }
                else if (charArray[i] == input) {
                    charAnswer[i] = charArray[i];
                }
            }





        }while(!(guesses == 0));
        check = Arrays.equals(charArray, charAnswer);
        if(check == true) {

            System.out.println("you win");
            System.out.println("The word is " + secret);
        }
        else {

            System.out.println("You Lost! Gameover");
            System.out.println("The word is " + secret);
        }
    } // End of main method




    public static int counter(char char1, char[] charArray, char[] charAnswer, int guessed){
        for (int i = 0; i < charArray.length; i++) {
            char ch2 = charArray[i];
            char char2 = charAnswer[i];
            if (char1 == ch2 || char1 == char2) {
                break;

            }
            else if(i == charArray.length - 1){
                guessed = guessed - 1;
                break;
            }

        }
        return guessed;
    }



    public static void checkAnswer(char char1, char[] charArray, char[] charAnswer){
        for (int i = 0; i < charArray.length; i++) {
            char ch2 = charArray[i];
            char char2 = charAnswer[i];
            if(char1 == char2){
                break;
            }
            if (char1 == ch2 && char1 != char2) {
                System.out.println("You guessed correctly!");
                break;
            }
            else if(i == charArray.length - 1 && char1 != char2){
                System.out.println("You guessed wrong");
                    break;

            }
            }
            }






    public static int getRand(){
        Random r = new Random();
        String[] loadWords = loadWords();
        int num = r.nextInt(loadWords.length);
        return num;
    }


    /* Helper Code -----------------------------------------------
     * You do not have to understand the provided helper methods
     * But you will have to know how/when to call these methods
     * Make sure to read the instructions
     * DO NOT make any changes to the methods below UNLESS specified
     * by the directions.
     */

    public static String[] loadWords()
    {
        /*
         * Returns a String array of valid words.
         * Also prints out the total number of words (Strings) in the array.
         */

        ArrayList<String> wordList = new ArrayList<>();
        File f = new File("words.txt");
        String[] wordsArr = new String[wordList.size()];
        try
        {
            Scanner in = new Scanner(f);
            while(in.hasNext())
            {
                String word = in.next();
                wordList.add(word);
            }
            in.close();
            System.out.println("Loading words from the file......");
            System.out.println(wordList.size()+" words loaded.");
            System.out.println("-------------");
            wordsArr = (String[])wordList.toArray(wordsArr);
        } catch (FileNotFoundException ex) {
            System.out.println("File not found.");
        }
        return wordsArr;
    }

    public static char[] stringToChar(String secretWord)
    {
        /**
         * takes a string which is a secretWord
         * Returns a char array of secretWord
         * You can use printArray method to test the output
         */
        char[] secretArr = new char[secretWord.length()];
        for (int i = 0; i < secretArr.length; i++)
        {
            secretArr[i] = secretWord.charAt(i);
        }
        return secretArr;
    }

    // End of Helper Code----------------------------------

} //program ends