
import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter Your Name: ");
   
   
   String name = input.nextLine();
   
   
   System.out.print("Hours worked this week: ");
   
   
   double hours = input.nextDouble();
   
   System.out.print("Please enter Pay Rate: ");
   
   double payRate = input.nextDouble();
   
  
   System.out.println(name);
  
   
   if (hours > 40) {
      double overTimeHours = (hours - 40);
      hours -=  overTimeHours;
      double overTimePayRate = payRate * 1.5;
      double regularPay = hours * payRate;
      double overTimePay = overTimePayRate * overTimeHours;
      double totalPay = overTimePay + regularPay;
      
      System.out.println("Regular pay: " + regularPay);
      System.out.println("Overtime pay: " + overTimePay);
      System.out.println("Total pay: " + totalPay);
    }  
   else {
   
   double regularPay = payRate * hours;
   
   System.out.println("Regular pay: " + regularPay);
   }
   
   
   }
   
   }