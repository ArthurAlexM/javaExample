
import java.util.Scanner;
public class Makes10
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("First Number: ");
   
   
   int x = input.nextInt();
   
   
   System.out.print("Second Number: ");
   
   
   int y = input.nextInt();
   
   if (x + y == 10) {
      System.out.println(x + " + " + y + "sums up to 10");
    }  
   else {
   
   System.out.println("Does not sum up to 10");
   }
   if (x ==10 || y == 10){
   
   System.out.println("One number is 10")
   
   }
   else {
      System.out.println("No number is 10");
   }