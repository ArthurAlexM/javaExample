/* This program is used to find the day easter is on based on user input for the year */

import java.util.Scanner;
public class SameLastDigit
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("First Number: ");
   
   
   int x = input.nextInt();
   
   
   System.out.print("Second Number: ");
   
   
   int y = input.nextInt();
   
   int firstnum = (x % 10);
   
   int secnum = (y % 10);
   
   if (firstnum == secnum) {
   
   System.out.println("Same last digit");
   
   }
   
   else {
   
   System.out.println("Different last digit");

  }
}

}