/* This program is used to find the day easter is on based on user input for the year */

import java.util.Scanner;
public class Problem2
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter an interger for year: ");
   int y = input.nextInt();
   

   
   int a = y % 19;
   int b = y / 100;
   int c = y % 100;
   int d = b / 4;
   int e = b % 4;
   int f = (b + 8) / 25;
   int g = (b - f + 1) / 3;
   int h = (19 * a + b - d - g + 15) % 30;
   int i = c / 4;
   int k = c % 4;
   int j = (32 + 2 * e + 2 * i - h - k) % 7;
   int m = (a + 11 * h + 22 * j) / 451;
   int n = (h + j - 7 * m + 114) / 31;
   int p = (h + j - 7 * m + 114) % 31;
 
   int Easter = 10 * (p + 1) + n;
   
   System.out.println("Day of Easter is: " + Easter);
   
   
   }
}