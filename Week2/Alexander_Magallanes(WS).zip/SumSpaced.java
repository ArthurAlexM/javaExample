/* This program is used to add up numbers that the user inputs counting all the way up to that number and giving the sum of the number. 
   It makes use of the mod operand to also display the sum spaced out. */

import java.util.Scanner;
public class SumSpaced
{
   public static void main(String[] args)
   {
   Scanner input = new Scanner(System.in);
   
   System.out.print("Enter a non-negative interger between 1-140: ");
   int n = input.nextInt();
   
   int sum = (n * (n+1))/2;
   
   System.out.println("the sum of the numbers counting up to " + n + " is equal to " +sum);
   
   int modFirst = (sum % 10);
   int modTwo = ((sum % 100)/10);
   int modThree = ((sum % 1000)/100);
   int modFour = ((sum % 10000)/1000);
   
   System.out.println("the sum of the interger seperated by spaces is: " + modFour + " " + modThree + " " + modTwo + " " + modFirst);
   
   
   }
}