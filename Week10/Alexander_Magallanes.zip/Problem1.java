import java.util.Scanner;
public class Problem1
{
   public static void main(String[] args)
   {
   
          int [] a1 = {1, 2, 3};
        int [] a2 = {-8, -7, -2, 1, -3};
        int [] a3 = {9};
        int n1 = maxThree(a1);
        int n2 = maxThree(a2);
        int n3 = maxThree(a3);
   
   System.out.println("Return value");
        System.out.println(n1);
        System.out.println(n2);
        System.out.println(n3);
   
   }
   
   public static int maxThree(int [] a){
     int first = a[0];
        int mid = a[a.length/2]; // because of the assumption that the array is at least 1 and odd we can find the middle index
        int last = a[a.length-1];
        if (a.length != 1)
        {
            if (first >= mid && first >= last)
                first = first;
            else if (mid >= first && mid >= last)
                first = mid;
            else
                first = last;
        }
        
   return first;
  
      
   
   
   
   
   }
   
  
   
   
   
   
   
   }